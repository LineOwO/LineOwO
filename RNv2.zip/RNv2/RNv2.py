#This program writes 1 line of 12 random integers, each in the
#range from 1-100 to a text file.

def main():

    import random

    #Open a file named numbersmake.txt.
    outfile = open('result.txt', 'w')

    #Produce the numbers
    for count in range(12):
        #Get a random number.
        num = random.randint(1, 100)

    #Write 12 random intergers in the range of 1-100 on one line
    #to the file.
    outfile.write(str(num))

    #Close the file.
    outfile.close()
    print('Data written to numbersmake.txt')

#Call the main function
main()