

def main():

    import random

    
    outfile = open('result.txt', 'w')

    
    for count in range(12):
        #Get a random number.
        num = random.randint(1, 100)

    
    outfile.write(str(num))

    
    outfile.close()
    print('Data written to numbersmake.txt')


main()