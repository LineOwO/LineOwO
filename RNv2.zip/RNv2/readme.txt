Default: 1-100

**Editing info**
Right click the file "RNv2.py"> Open With> Notepad
Find the line that says "num = random.randint(1, 100)"
And just change the numbers it's easy like that.

**Results**
After running the code there will be a file called "result.txt"
You don't have to delete it it will just replace itself if you run the code more times

**Pre Schooler stuff**
You need python to run this file, thank you for understanding.

